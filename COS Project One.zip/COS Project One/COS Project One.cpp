#include <iostream>
#include <sstream>

using namespace std;


class Clock {
public:
    int h, m, s;

    Clock() {
        this->h = 0;
        this->m = 0;
        this->s = 0;
    }

    string nCharString(size_t n, char c) {
        string x;
        for (int i = 0; i < n; i++) {
            x += c;
        }
        return x;
    }

    string twoDigitString(unsigned int n) {
        string x;
        string zero = "0";
        if (n < 10) {
            x = zero + std::to_string(n);
        }
        else {
            x = std::to_string(n);
        }
        return x;
    }

    string formatTime24(unsigned int h, unsigned int m, unsigned int s) {
        string time = twoDigitString(h) + ":" + twoDigitString(m) + ":" + twoDigitString(s);

        return time;
    }

    string formatTime12(unsigned int h, unsigned int m, unsigned int s) {
        string AmPm;
        if (h >= 12) {
            AmPm = "P M";
            h = h - 12;
        }
        else {
            AmPm = "A M";
        }
        if (h == 0) {
            h = 12;
        }
        string time = twoDigitString(h) + ":" + twoDigitString(m) + ":" + twoDigitString(s) + " " + AmPm;

        return time;
    }

    unsigned int getMenuChoice(unsigned int maxChoice) {

        int x = 0;
        int option;
        while (x == 0) {
            cin >> option;
            if ((option <= maxChoice) && (option > 0)) {
                x = 1;
            }
        }
        return option;
    }

    void displayClocks() {
        std::cout << nCharString(27, '*') << nCharString(3, ' ') << nCharString(27, '*') << endl;

        std::cout << nCharString(1, '*') << nCharString(6, ' ') << "12-HOUR CLOCK" << nCharString(6, ' ') << nCharString(1, '*') << nCharString(3, ' ');

        std::cout << nCharString(1, '*') << nCharString(6, ' ') << "24-HOUR CLOCK" << nCharString(6, ' ') << nCharString(1, '*') << endl;

        std::cout << endl;

        std::cout << nCharString(1, '*') << nCharString(6, ' ') << formatTime12(h, m, s) << nCharString(7, ' ') << nCharString(1, '*') << nCharString(3, ' ');

        std::cout << nCharString(1, '*') << nCharString(8, ' ') << formatTime24(h, m, s) << nCharString(9, ' ') << nCharString(1, '*') << endl;

        std::cout << nCharString(27, '*') << nCharString(3, ' ') << nCharString(27, '*') << endl;
    }

    void printMenu() {
        std::cout << nCharString(27, '*') << endl;
        std::cout << nCharString(1, '*') << nCharString(25, ' ') << nCharString(1, '*') << endl;
        std::cout << nCharString(1, '*') << nCharString(5, ' ') << "Add One Hour   " << nCharString(5, ' ') << nCharString(1, '*') << endl;
        std::cout << nCharString(1, '*') << nCharString(5, ' ') << "Add One Minute " << nCharString(5, ' ') << nCharString(1, '*') << endl;
        std::cout << nCharString(1, '*') << nCharString(5, ' ') << "Add One Second " << nCharString(5, ' ') << nCharString(1, '*') << endl;
        std::cout << nCharString(1, '*') << nCharString(5, ' ') << "Exit Program   " << nCharString(5, ' ') << nCharString(1, '*') << endl;
        std::cout << nCharString(1, '*') << nCharString(25, ' ') << nCharString(1, '*') << endl;
        std::cout << nCharString(27, '*') << endl;
    }

    void addOneSecond() {
        int sec = getSecond();

        if (sec >= 0 && sec <= 58) {
            setSecond(sec + 1);
        }
        if (sec == 59) {
            setSecond(0);
            addOneMinute();
        }
    }
    int getSecond() {
        return s;
    }
    void setSecond(int sec) {
        this->s = sec;
    }

    void addOneMinute() {
        int min = getMinute();

        if (min >= 0 && min <= 58) {
            setMinute(min + 1);
        }
        if (min == 59) {
            setMinute(0);
            addOneHour();
        }
    }
    int getMinute() {
        return m;
    }
    void setMinute(int min) {
        this->m = min;
    }

    void addOneHour() {
        int hour = getHour();

        if (hour >= 0 && hour <= 22) {
            setHour(hour + 1);
        }
        if (hour == 23) {
            setHour(0);
        }
    }
    int getHour() {
        return h;
    }
    void setHour(int hour) {
        this->h = hour;
    }
};

void main() {
    Clock c;
    int x = 0;
    int choice;

    while (x == 0) {
        c.displayClocks();
        c.printMenu();
        choice = c.getMenuChoice(4);
        if (choice == 1) {
            c.addOneHour();
        }
        else if (choice == 2) {
            c.addOneMinute();
        }
        else if (choice == 3) {
            c.addOneSecond();
        }
        else if (choice == 4) {
            x = 1;
        }
    }

}
